sap.ui.define(["sap/suite/ui/generic/template/lib/AppComponent"], function(AppComponent) {
    return AppComponent.extend("sap.fe.demo.bookinganalysis.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
